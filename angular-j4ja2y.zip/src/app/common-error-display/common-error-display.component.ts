import { Component, Input, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'common-error-display',
  templateUrl: './common-error-display.component.html',
  styleUrls: ['./common-error-display.component.css'],
})
export class CommonErrorDisplayComponent implements OnInit {
  constructor() {}
  @Input('error') error: any;
  @Input('showError')showError:boolean;
  ngOnInit() {}
}
