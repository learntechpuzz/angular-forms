import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrls: ['./template-driven-form.component.css'],
})
export class TemplateDrivenFormComponent implements OnInit {
  constructor() {}

  public name: string = '';
  public email: string = '';
  public dob: string = '';
  public phone: string = '';
  public tempForm: NgForm;
  public showError: boolean = false;

  ngOnInit() {}

  submitTempForm(form) {
    this.showError = true;
    this.scrollToFirstError(form.form.controls);
  }

  scrollToFirstError(controls) {
    for (let x in controls) {
      if (controls[x].errors) {
        document.querySelector('#' + x).scrollIntoView();
        break;
      }
    }
  }
}
